package com.example.demoexample3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demoexample3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
