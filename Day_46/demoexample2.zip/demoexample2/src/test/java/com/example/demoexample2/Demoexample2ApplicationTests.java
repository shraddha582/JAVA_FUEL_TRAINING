package com.example.demoexample2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demoexample2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
