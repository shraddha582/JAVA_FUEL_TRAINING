package com.example.demoexample1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demoexample1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
