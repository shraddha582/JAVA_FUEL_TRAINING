package com.example.demoEmployeeApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoEmployeeAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
