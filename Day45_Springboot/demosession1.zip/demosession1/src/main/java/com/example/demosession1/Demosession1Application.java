package com.example.demosession1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demosession1Application {

	public static void main(String[] args) {
		SpringApplication.run(Demosession1Application.class, args);
	}

}
