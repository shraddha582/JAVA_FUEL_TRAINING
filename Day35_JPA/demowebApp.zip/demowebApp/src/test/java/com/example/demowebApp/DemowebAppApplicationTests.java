package com.example.demowebApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemowebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
