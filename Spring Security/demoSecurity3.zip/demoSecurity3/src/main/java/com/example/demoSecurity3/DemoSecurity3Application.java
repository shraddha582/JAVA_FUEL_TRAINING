package com.example.demoSecurity3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSecurity3Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoSecurity3Application.class, args);
	}

}
