package com.example.demohtml2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demohtml2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
