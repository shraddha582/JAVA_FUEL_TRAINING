package com.example.demohtml;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemohtmlApplicationTests {

	@Test
	void contextLoads() {
	}

}
