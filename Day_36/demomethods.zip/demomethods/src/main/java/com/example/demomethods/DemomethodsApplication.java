package com.example.demomethods;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemomethodsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemomethodsApplication.class, args);
	}

}
