package com.example.demomanytoone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemomanytooneApplicationTests {

	@Test
	void contextLoads() {
	}

}
