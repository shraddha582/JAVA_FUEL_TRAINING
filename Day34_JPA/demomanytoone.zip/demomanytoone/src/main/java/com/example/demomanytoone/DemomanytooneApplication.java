package com.example.demomanytoone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemomanytooneApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemomanytooneApplication.class, args);
	}

}
